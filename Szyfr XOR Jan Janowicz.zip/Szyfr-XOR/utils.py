"""
Potrzebne parametry i funkcje pomocnicze
"""

class Utils:

    def __init__(self):
        self.dictionary_small_letters = {chr(i): i - 97 for i in range(97, 123)}
        self.dictionary_big_letters = {chr(i): i - 65 for i in range(65, 91)}

    def read(self, file: str) -> str:
        with open(file, "r") as p:
            return p.read()

    def write(self, file: str, text: str) -> None:
        with open(file, "w") as p:
            p.write(text)

    def append(self, file: str, text: str) -> None:
        with open(file, "a") as p:
            p.write(text)

    def check_correctness(self) -> None:
        decrypt_text = self.read("decrypt.txt")
        plain_text = self.read("plain.txt")
        correctness = 0
        mistakes = 0
        unknown = 0

        for index in range(len(plain_text)):
            if decrypt_text[index] == '_':
                unknown += 1
            elif decrypt_text[index] == plain_text[index]:
                correctness += 1
            elif decrypt_text[index] != plain_text[index]:
                print(f"Bledny znak: {decrypt_text[index]} w miejscu {index} powinno byc {plain_text[index]}")
                mistakes += 1

        print(f"Poprawne: {correctness/len(plain_text)}%, Bledy: {mistakes/len(plain_text)}%, Nieznane: {unknown/len(plain_text)}%")
